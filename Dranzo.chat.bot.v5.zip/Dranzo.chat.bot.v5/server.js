const express = require('express');
const bodyParser = require('body-parser');
const { GoogleGenerativeAI, GoogleGenerativeAIFetchError } = require('@google/generative-ai');
const pdfkit = require('pdfkit');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch'); // For manual token exchange

const { ZohoSign } = require('@zohosign/nodejs-sdk-1.0/src/ZohoSign.js');
const { OAuth } = require('@zohosign/nodejs-sdk-1.0/src/Oauth.js');
const { RequestObject } = require('@zohosign/nodejs-sdk-1.0/src/api/RequestObject.js');
const { Actions } = require('@zohosign/nodejs-sdk-1.0/src/api/Action.js');


require('dotenv').config();

// --- Pre-startup Checks ---
if (!process.env.GEMINI_API_KEY) {
    console.error("FATAL ERROR: GEMINI_API_KEY is not defined in your .env file.");
    process.exit(1);
}

const app = express();
const port = 5003;

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// In-memory session storage
const sessions = {};

const agreementFields = {
    "home rental agreement": [
        "Date of Agreement",
        "Landlord's Full Name",
        "Landlord's Mailing Address",
        "Tenant's Full Name(s)",
        "Property Address",
        "Start Date",
        "End Date",
        "Rent Amount",
        "Security Deposit Amount"
    ],
    "loan agreement": [
        "Date of Agreement",
        "Lender's Full Name",
        "Lender's Full Address",
        "Borrower's Full Name",
        "Borrower's Full Address",
        "Loan Amount",
        "Interest Rate",
        "Repayment Terms"
    ],
    "shop rental agreement": [
        "Date of Agreement",
        "Landlord's Full Name",
        "Landlord's Mailing Address",
        "Tenant's/Business Name",
        "Property Address",
        "Start Date",
        "End Date",
        "Rent Amount",
        "Security Deposit Amount"
    ]
};

app.use(express.static('public'));
app.use(bodyParser.json({ limit: '5mb' }));

app.get('/auth/zoho', (req, res) => {
    const { clientId } = req.query;
    if (!clientId || !sessions[clientId]) {
        return res.status(400).send('Invalid or missing client ID.');
    }
    const dc = "eu"; // or "com", "in", etc.
    const scope = "ZohoSign.documents.ALL,ZohoSign.templates.ALL";
    const responseType = "code";
    const accessType = "offline";

    const authUrl = `https://accounts.zoho.${dc}/oauth/v2/auth?scope=${scope}&client_id=${process.env.ZOHO_CLIENT_ID}&response_type=${responseType}&redirect_uri=${process.env.ZOHO_REDIRECT_URI}&access_type=${accessType}&state=${clientId}`;
    
    res.redirect(authUrl);
});

app.get('/oauth/callback', async (req, res) => {
    const { code, state: clientId } = req.query;
    if (!code || !clientId) {
        return res.status(400).send('Authorization code or state is missing.');
    }

    if (!sessions[clientId]) {
        return res.status(400).send('Session not found for the given client ID.');
    }

    try {
        const dc = "eu"; // or "com", "in", etc.
        const tokenUrl = `https://accounts.zoho.${dc}/oauth/v2/token`;
        const params = new URLSearchParams();
        params.append('grant_type', 'authorization_code');
        params.append('client_id', process.env.ZOHO_CLIENT_ID);
        params.append('client_secret', process.env.ZOHO_CLIENT_SECRET);
        params.append('redirect_uri', process.env.ZOHO_REDIRECT_URI);
        params.append('code', code);

        const response = await fetch(tokenUrl, {
            method: 'POST',
            body: params
        });

        const tokenData = await response.json();

        if (tokenData.error) {
            throw new Error(tokenData.error);
        }

        sessions[clientId].zoho_token = tokenData;
        console.log('Zoho token obtained and stored for client:', clientId);
        res.send('<script>window.close();</script>'); // Close the popup window
    } catch (error) {
        console.error('Error generating Zoho token:', error);
        res.status(500).send('Failed to obtain Zoho token.');
    }
});

// Helper function for robust API calls with retry logic
async function generateContentWithRetry(model, prompt, retries = 3, delay = 1000) {
    try {
        const result = await model.generateContent(prompt);
        return result;
    } catch (error) {
        // Check for specific, transient error status codes like 503 Service Unavailable or 429 Resource Exhausted
        if (error instanceof GoogleGenerativeAIFetchError && (error.status === 503 || error.status === 429) && retries > 0) {
            console.log(`API call failed with status ${error.status}. Retrying in ${delay}ms... (${retries} retries left)`);
            await new Promise(resolve => setTimeout(resolve, delay));
            // Exponential backoff
            return generateContentWithRetry(model, prompt, retries - 1, delay * 2);
        } else {
            // For non-retryable errors, re-throw
            console.error("API call failed after retries or with a non-retryable error.", error);
            throw error;
        }
    }
}

app.post('/api/chat', async (req, res) => {
    const { clientId, message } = req.body;
    console.log(`\n--- New Request ---`);
    console.log(`Client ID: ${clientId}`);
    console.log(`Message: "${message}"`);

    if (sessions[clientId] && sessions[clientId].status === 'completed') {
        console.log("Previous session was completed. Starting a new one.");
        delete sessions[clientId];
    }

    const resetKeywords = ['create', 'make', 'new', 'start over', 'reset', 'agrement', 'eggrenet'];
    const messageLower = message.toLowerCase();
    if (resetKeywords.some(keyword => messageLower.includes(keyword))) {
        if (sessions[clientId]) { // Check if session exists, it might have been deleted.
            console.log("Reset keyword detected. Deleting session.");
            delete sessions[clientId];
        }
    }

    if (!sessions[clientId]) {
        console.log("No active session found. Creating a new one.");
        sessions[clientId] = {
            status: 'collecting_data',
            agreementType: null,
            requiredFields: [],
            collectedData: {}
        };
    } else {
        console.log("Active session found. Status:", sessions[clientId].status);
    }

    const session = sessions[clientId];
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

    try {
        if (session.status === 'reviewing_agreement') {
            if (messageLower.includes('yes') || messageLower.includes('correct')) {
                session.status = 'prompt_for_signing';
                res.json({ ok: true, reply: "Great! The document is correct. Would you like to send it for signing now? (yes/no)" });
            } else {
                session.status = 'collecting_data';
                // A more robust implementation would allow for specific corrections.
                res.json({ ok: true, reply: "I see. Let's start over. What kind of agreement would you like to create?" });
            }
        } else if (session.status === 'prompt_for_signing') {
            if (messageLower.includes('yes')) {
                session.status = 'collecting_signer_info';
                res.json({ ok: true, reply: "Who will be signing this document? Please provide the signer's full name and email address (e.g., John Doe, john.doe@example.com)." });
            } else { // Handles 'no' or any other response
                session.status = 'completed'; // End the flow
                res.json({
                    ok: true,
                    reply: `Okay, the agreement is available for you to download. <a href="${session.pdfUrl}" target="_blank">Click here to view it</a>. Let me know when you want to create a new agreement.`,
                    pdfUrl: session.pdfUrl
                });
            }
        } else if (session.status === 'collecting_signer_info') {
            // Basic parsing for name and email
            const parts = message.split(',');
            if (parts.length === 2) {
                const name = parts[0].trim();
                const email = parts[1].trim();
                session.signer = { name, email };
                session.status = 'ready_to_sign';

                if (!session.zoho_token) {
                     res.json({
                        ok: true,
                        reply: `Thank you. To send the document for signing with Zoho Sign, you need to authenticate. <a href="/auth/zoho?clientId=${clientId}" target="_blank">Click here to connect your Zoho account</a>. After you've connected, tell me to "proceed with signing".`
                    });
                } else {
                    await sendForSigning(session, res, clientId);
                }

            } else {
                res.json({ ok: true, reply: "Please provide the signer's full name and email address, separated by a comma." });
            }
        } else if (session.status === 'ready_to_sign' && messageLower.includes('proceed')) {
             if (!session.zoho_token) {
                 res.json({
                    ok: true,
                    reply: `You still need to authenticate with Zoho. <a href="/auth/zoho?clientId=${clientId}" target="_blank">Click here to connect your Zoho account</a>. After you've connected, tell me to "proceed with signing".`
                });
            } else {
                await sendForSigning(session, res, clientId);
            }
        }
        else if (session.status === 'collecting_data') {
            if (!session.agreementType) {
                const prompt = `What type of legal agreement is the user asking for in the following message? Message: "${message}". Respond with the type of agreement (e.g., "Rental Agreement", "Loan Agreement") or "none".`;
                const result = await generateContentWithRetry(model, prompt);
                const response = await result.response;
                const agreementType = await response.text();

                if (agreementType.toLowerCase().trim() !== 'none') {
                    session.agreementType = agreementType.toLowerCase().trim();
                    
                    if (agreementFields[session.agreementType]) {
                        session.requiredFields = agreementFields[session.agreementType];
                        session.currentFieldIndex = 0; // Initialize field index
                        const firstField = session.requiredFields[0];
                        res.json({
                            ok: true,
                            reply: `To create a ${session.agreementType}, I need some information. Let's start with the ${firstField}.`
                        });
                    } else {
                        const fieldsPrompt = `List the absolute essential, top-level fields required to create a ${session.agreementType}. Focus on names, addresses, dates, and amounts. Do not include boilerplate legal clauses like "Governing Law". Respond with a JSON array of strings.`;
                        const fieldsResult = await generateContentWithRetry(model, fieldsPrompt);
                        const fieldsResponse = await fieldsResult.response;
                        const fieldsText = await fieldsResponse.text();
                        
                        try {
                            const jsonMatch = fieldsText.match(/\s*\[.*\]\s*/s);
                            if (jsonMatch && jsonMatch[0]) {
                                session.requiredFields = JSON.parse(jsonMatch[0]);
                                if (session.requiredFields.length > 0) {
                                    session.currentFieldIndex = 0; // Initialize field index
                                    const firstField = session.requiredFields[0];
                                    res.json({
                                        ok: true,
                                        reply: `To create a ${session.agreementType}, I need some information. Let's start with the ${firstField}.`
                                    });
                                } else {
                                    session.status = 'waiting_for_user_fields';
                                    res.json({ ok: true, reply: `I'm not familiar with the specific requirements for a ${session.agreementType}. Could you please list the essential fields you'd like to include in this agreement, separated by commas?` });
                                }
                            } else {
                                throw new Error("Could not parse required fields from model response.");
                            }
                        } catch (e) {
                            console.error("Error parsing fields from Gemini:", e);
                            session.status = 'waiting_for_user_fields';
                            res.json({ ok: true, reply: `I had trouble understanding the requirements for a ${session.agreementType}. Could you please list the essential fields you'd like to include, separated by commas?` });
                        }
                    }
                } else {
                    res.json({ ok: true, reply: "I can help you create legal agreements. What would you like to create?" });
                }
            } else {
                // Simplified sequential data collection
                if (session.currentFieldIndex === undefined) {
                    session.currentFieldIndex = 0;
                }

                const currentField = session.requiredFields[session.currentFieldIndex];

                // If the message is not a proceed keyword, save the data.
                const proceedKeywords = ['proceed', 'thats all', 'generate', 'create pdf', 'done', 'nill', 'nil'];
                 if (!proceedKeywords.some(keyword => messageLower.includes(keyword))) {
                    if (currentField) {
                        session.collectedData[currentField] = message;
                        session.currentFieldIndex++;
                    }
                }
                
                const nextField = session.requiredFields[session.currentFieldIndex];

                if (nextField) {
                    res.json({
                        ok: true,
                        reply: `Thanks. Now, please provide the ${nextField}.`
                    });
                } else {
                    // All fields collected
                    session.status = 'generating_pdf';
                    await generatePdf(session, res, genAI);
                }
            }
        } else if (session.status === 'waiting_for_user_fields') {
            session.requiredFields = message.split(',').map(field => field.trim());
            session.status = 'collecting_data';
            res.json({
                ok: true,
                reply: `Thank you. Now, please provide the information for the following fields:\n- ${session.requiredFields.join('\n- ')}`
            });
        }
    } catch (error) {
        console.error("Error in /api/chat:", error);
        res.status(500).json({ ok: false, reply: "An error occurred. Please try again." });
    }
});

async function generatePdf(session, res, genAI) {
    try {
        // 1. Generate Agreement Text with Gemini
        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
        const agreementPrompt = `You are a helpful assistant for creating legal agreements.
Your task is to write a complete and formal ${session.agreementType}.
**Instructions:**
1. Write the agreement using the data provided in the "Details" JSON object.
2. Incorporate all the provided details into the text of the agreement.
3. For any general legal clauses not covered by the details (like "Governing Law"), use standard, brief, and common legal language.
4. The final document must be concise and complete, fitting on a single A4 page. Do not use placeholders.
**Details:**
${JSON.stringify(session.collectedData, null, 2)}
Now, write the complete ${session.agreementType}.`;
        const agreementResult = await generateContentWithRetry(model, agreementPrompt);
        const agreementResponse = await agreementResult.response;
        const agreementText = await agreementResponse.text();

        // 2. Generate PDF
        const doc = new pdfkit({ size: 'A4', margin: 50 });
        const fileName = `${session.agreementType.replace(/\s/g, '_')}_${Date.now()}.pdf`;
        const filePath = path.join(__dirname, 'public', 'agreements', fileName);
        session.pdfPath = filePath; // Store full path for sending to Zoho
        session.pdfFileName = fileName; // Store filename for Zoho

        doc.fontSize(10).text(agreementText, {
            align: 'justify',
            height: 700, // Restrict height to fit on one page
            ellipsis: true
        });

        const stream = fs.createWriteStream(filePath);
        doc.pipe(stream);
        doc.end();

        stream.on('finish', () => {
            const fileUrl = `/agreements/${path.basename(filePath)}`;
            session.status = 'reviewing_agreement';
            session.pdfUrl = fileUrl; // Keep this for the review link
            res.json({
                ok: true,
                reply: `I have created the ${session.agreementType}. You can <a href="${fileUrl}" target="_blank">review it here</a>. Does everything look correct?`,
                pdfUrl: fileUrl
            });
        });

    } catch (error) {
        console.error("Error in generatePdf:", error);
        res.status(500).json({ ok: false, reply: "An error occurred while generating the PDF. Please check the server logs." });
    }
}

async function sendForSigning(session, res, clientId) {
    if (!session.pdfPath || !session.signer) {
        return res.status(400).json({ ok: false, reply: 'Missing PDF or signer information.' });
    }

    try {
        const user = new OAuth({
            CLIENT_ID: process.env.ZOHO_CLIENT_ID,
            CLIENT_SECRET: process.env.ZOHO_CLIENT_SECRET,
            DC: 'eu',
            ACCESS_TOKEN: session.zoho_token.access_token,
            REFRESH_TOKEN: session.zoho_token.refresh_token
        });

        const reqObj = new RequestObject();
        reqObj.setRequestName(session.pdfFileName);

        const signer = new Actions();
        signer.setRecipientName(session.signer.name);
        signer.setRecipientEmail(session.signer.email);
        signer.setActionType('SIGN');
        reqObj.addAction(signer);

        const filePath = [session.pdfPath];
        
        const draftJSON = await ZohoSign.draftRequest(reqObj, filePath, user);
        const response = await ZohoSign.submitForSignature(draftJSON, user);

        console.log('Zoho Sign response:', response);

        session.status = 'signing_initiated';
        res.json({ ok: true, reply: `The document has been sent to ${session.signer.email} for signing via Zoho Sign.` });

    } catch (error) {
        console.error('Error sending document for signing:', error);
        // Handle token expiration
        if (error.message && error.message.includes('invalid_token')) {
             res.json({
                ok: true,
                reply: `Your Zoho session has expired. Please authenticate again. <a href="/auth/zoho?clientId=${clientId}" target="_blank">Click here to reconnect your Zoho account</a>. After you've connected, tell me to "proceed with signing".`
            });
        } else {
            res.status(500).json({ ok: false, reply: 'An error occurred while sending the document for signing.' });
        }
    }
}

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
