const clientId = "client_" + Math.random().toString(36).substring(2, 9);
const chatBox = document.getElementById("chat-box");
const messageInput = document.getElementById("message");
const sendBtn = document.getElementById("sendBtn");
const actionContainer = document.getElementById("action-container");

let zohoAuthPopup = null;

function appendMessage(sender, text) {
  const msgDiv = document.createElement("div");
  msgDiv.className = `msg ${sender}`;
  // Use innerHTML to render the links for Zoho auth and PDF viewing
  msgDiv.innerHTML = text.replace(/\n/g, '<br>');
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;

  // Add event listener for Zoho authentication link
  const authLink = msgDiv.querySelector('a[href^="/auth/zoho"]');
  if (authLink) {
    authLink.addEventListener('click', (e) => {
      e.preventDefault();
      const authUrl = e.target.href;
      // Open a popup window for OAuth
      zohoAuthPopup = window.open(authUrl, 'zohoAuth', 'width=600,height=700');
    });
  }
}

async function sendMessage() {
  const message = messageInput.value.trim();
  if (!message) return;
  
  appendMessage("user", message);
  messageInput.value = "";

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clientId, message }),
    });
    const data = await res.json();

    if (data.ok) {
        appendMessage("bot", data.reply);
    } else {
      appendMessage("bot", data.reply || "Something went wrong.");
    }
  } catch (error) {
    console.error("Error sending message:", error);
    appendMessage("bot", "An error occurred while communicating with the server.");
  }
}

// Listen for the popup to close
const popupCloseTimer = setInterval(() => {
    if (zohoAuthPopup && zohoAuthPopup.closed) {
        clearInterval(popupCloseTimer);
        appendMessage('bot', 'Authentication complete! Please type "proceed with signing" to send the document.');
        zohoAuthPopup = null;
    }
}, 1000);


sendBtn.addEventListener("click", sendMessage);
messageInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});
